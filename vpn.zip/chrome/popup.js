const host = document.getElementById("host")
const port = document.getElementById("port")
const username = document.getElementById("username")
const password = document.getElementById("password")

const loader = document.getElementById("loader")
const status = document.getElementById("status")

chrome.storage.local.get("proxy",(data)=>{

if(data.proxy){

host.value=data.proxy.host
port.value=data.proxy.port
username.value=data.proxy.username
password.value=data.proxy.password

}

})

document.getElementById("connect").onclick=()=>{

loader.style.display="block"
status.innerText="Connecting..."

const proxy={

host:host.value,
port:port.value,
username:username.value,
password:password.value

}

chrome.runtime.sendMessage({
action:"connect",
proxy:proxy
})

setTimeout(()=>{

loader.style.display="none"
status.innerText="Connected"

},1200)

}

document.getElementById("disconnect").onclick=()=>{

chrome.runtime.sendMessage({
action:"disconnect"
})

status.innerText="Disconnected"

}
