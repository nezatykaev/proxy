function setProxy(proxy) {

    const config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: proxy.host,
                port: parseInt(proxy.port)
            }
        }
    };

    chrome.proxy.settings.set(
        { value: config, scope: "regular" }
    );
}

function clearProxy() {

    chrome.proxy.settings.clear({ scope: "regular" });

}

chrome.runtime.onMessage.addListener((msg) => {

    if (msg.action === "connect") {

        chrome.storage.local.set({ proxy: msg.proxy });

        setProxy(msg.proxy);

    }

    if (msg.action === "disconnect") {

        clearProxy();

    }

});

chrome.webRequest.onAuthRequired.addListener(

    (details, callback) => {

        chrome.storage.local.get("proxy", (data) => {

            if (!data.proxy) return;

            callback({
                authCredentials: {
                    username: data.proxy.username,
                    password: data.proxy.password
                }
            });

        });

    },

    { urls: ["<all_urls>"] },

    ["asyncBlocking"]

);
